import { Injectable } from '@angular/core';
import * as jwt from 'jsonwebtoken';
import { Router } from '@angular/router';

function getCookie(name){
  var strcookie = document.cookie;
  var arrcookie = strcookie.split("; ");
  for ( var i = 0; i < arrcookie.length; i++) {
    var arr = arrcookie[i].split("=");
    if (arr[0] == name){
      return arr[1];
    }
  }
  return "";
}

@Injectable()
export class BlogService {
  private posts: Post[];
  private max_id: number;
  private username: string;
  alert:Post;

  constructor(private router:Router) {
    this.alert=new Post(0,0,0,"","");
    this.max_id=0;
    var token=getCookie('jwt');
    var decoded = jwt.decode(token);
    console.log(decoded);
    if(decoded===null)
      window.location.href='http://localhost:3000/login?redirect=/edit/'
    this.username=decoded.usr;
    this.fetchPosts();
    
  }
  
  fetchPosts(): void{
    this.posts=[];
    var xmlHttp = new XMLHttpRequest(); 
    var request = 'http://localhost:3000/api/'+encodeURI(this.username);
    xmlHttp.open("GET", request); 
    xmlHttp.onreadystatechange = ()=>{
      if (xmlHttp.readyState == 4 && xmlHttp.status == 200) {
      var data = JSON.parse(xmlHttp.responseText);
        for(let post of data){
          if(post.postid>this.max_id)
            this.max_id=post.postid;
          let next=new Post(post.postid,new Date(post.created),
              new Date(post.modified),post.title,post.body);
          this.posts.push(next);
        }
      }
    };
    xmlHttp.send(null);
  }
  
  getPosts(): Post[]{
  	return this.posts;
  }

  getPost(id: number): Post{
  	for(let i in this.posts){
  		if(this.posts[i].postid===id)
  			return this.posts[i];
  	}
  	return null;
  }

  newPost(): Post{
    this.max_id++;
    var new_post=new Post(this.max_id,new Date(),new Date(),"","");
    let index=this.posts.push(new_post);

    let new_post_json=JSON.stringify(
      {username:this.username,
        title:"",
        body:"",
        postid:this.max_id});

    var request = "http://localhost:3000/api/"+encodeURI(this.username)+'/'+(this.max_id);
    var xmlHttp = new XMLHttpRequest(); 
  	xmlHttp.open("POST", request, true);
    xmlHttp.setRequestHeader("Content-Type", "application/json");
    xmlHttp.send(new_post_json);
    xmlHttp.onreadystatechange = ()=>{
      if (xmlHttp.readyState == 4 && xmlHttp.status !== 201){
        this.max_id--;
        this.posts.splice(index-1,1);
        this.alert.title="Error: there was an error creating a new post at the server";
        this.router.navigate(['/']);
      }
      else if (xmlHttp.readyState == 4 && xmlHttp.status === 201)
        this.alert.title="Success: Create a New Post";
    };
    return new_post;
  }

  updatePost(post: Post): void{
  	for(let p of this.posts){
  		if(p.postid===post.postid){
        p=post;
        var request = "http://localhost:3000/api/"+encodeURI(this.username)+'/'+(p.postid);
        var xmlHttp = new XMLHttpRequest(); 
        xmlHttp.open("PUT", request, true);
        let new_post_json=JSON.stringify(
          {username:this.username,
          title:post.title,
          body:p.body,
          postid:p.postid
        });
        xmlHttp.setRequestHeader("Content-Type", "application/json");
        xmlHttp.send(new_post_json);
        xmlHttp.onreadystatechange = ()=>{
          if (xmlHttp.readyState == 4 && xmlHttp.status !== 200){
            this.alert.title="Error: there was an error modifying a new post at the server";
            this.router.navigate(['/edit/'+p.postid]);
          }
          else if (xmlHttp.readyState == 4 && xmlHttp.status === 200)
            this.alert.title="Success: Post Saved";
        };
  			return;
  		}
  	  }
    }

  deletePost(id: number): void {
  	for(let i=0;i<this.posts.length;i++){
  		if(this.posts[i].postid===id){
        var request = "http://localhost:3000/api/"+encodeURI(this.username)+'/'+(id);
        var xmlHttp = new XMLHttpRequest(); 
        xmlHttp.open("DELETE", request, true);
        xmlHttp.onreadystatechange = ()=>{
          if (xmlHttp.readyState == 4 && xmlHttp.status !== 204)
            this.alert.title="Error:  there was an error deleting the post at the server";
          else if (xmlHttp.readyState == 4 && xmlHttp.status === 204)
            this.alert.title="Success: Post Deleted";
        };
        xmlHttp.send(null);
  			this.posts.splice(i,1);
  			return;
  		}
  	}
  }
}


export class Post {
	postid: number;
	created: Date;
	modified: Date;
	title: string;
	body: string;

	constructor(postid,created,modified,title,body){
		this.postid=postid;
		this.created=created;
		this.modified=modified;
		this.title=title;
		this.body=body;
	}
}