import { Component, OnInit } from '@angular/core';
import {BlogService, Post} from '../blog.service';

@Component({
  selector: 'app-error',
  templateUrl: './error.component.html',
  styleUrls: ['./error.component.css']
})
export class ErrorComponent implements OnInit {
  alert;
  constructor(private BlogService: BlogService) {
  	this.alert=this.BlogService.alert;
  }
  ngOnInit() {
  }

}
